# Tapeline

Tapeline is a Factorio mod adding a way to measure distances to the game.

[Download on the Mod Portal.](https://mods.factorio.com/mod/Tapeline)

## Features

![](resources/demo.gif)

Draw temporary measurements or measurements that persist and can be edited, adjusted, or deleted. See the included in-game tips and tricks for in-depth explanations.