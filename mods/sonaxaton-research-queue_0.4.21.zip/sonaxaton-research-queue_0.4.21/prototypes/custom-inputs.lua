data:extend{
  {
    type = 'custom-input',
    name = 'rq-toggle-main-window',
    key_sequence = 'SHIFT + T',
    order = 'a',
  },
  {
    type = 'custom-input',
    name = 'rq-focus-search',
    key_sequence = 'CONTROL + F',
    order = 'b',
  },
}
