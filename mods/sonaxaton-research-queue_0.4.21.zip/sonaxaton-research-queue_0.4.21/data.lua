require('prototypes.custom-inputs')
require('prototypes.shortcuts')
require('prototypes.sprites')
require('prototypes.styles')
