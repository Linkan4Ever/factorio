local b = {}

b["robotMiningSite-extra"] = true
b["robotMiningSite-large"] = true
b["robotMiningSite-new"] = true
b["invisible-logistic-chest-storage"] = true
b["robot-chest-provider"] = true
b["robot-chest-requester"] = true
b["construction-recaller"] = true
b["logistic-recaller"] = true

return b
